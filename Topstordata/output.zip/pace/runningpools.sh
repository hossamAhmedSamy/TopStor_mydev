cd /pacedata/
echo $@ >> runningpools
