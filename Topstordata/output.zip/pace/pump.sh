#!/bin/sh
echo $@ > /tmp2/msgfile;
