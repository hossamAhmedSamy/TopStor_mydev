#!/usr/bin/python3
print("hello world")
