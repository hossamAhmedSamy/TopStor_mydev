#!/usr/local/bin/zsh
echo $@ > tmppump;
